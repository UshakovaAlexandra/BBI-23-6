﻿using System;
using System.Collections.Generic;
using lab9_task2;
using ProtoBuf;

[ProtoContract]
[Serializable]
[ProtoInclude(1, typeof(Student))]
public class Person
{
    private string fullName;
    [ProtoMember(2)]
    public string FullName
    {
        get { return fullName; }
        set { fullName = value; }
    }
    public Person() { }
    public Person(string fullName)
    {
        this.fullName = fullName;
    }
}

[ProtoContract]
[Serializable]
public class Student : Person
{
    [ProtoMember(3)]
    public string StudentID { get; set; }
    [ProtoMember(4)]
    public List<double> ExamScores { get; set; }

    public double GetAverageScore()
    {
        double sum = 0;
        foreach (double score in ExamScores)
        {
            sum += score;
        }
        return sum / ExamScores.Count;
    }
    public Student() { }
    public Student(string fullName, string studentID, List<double> examScores) : base(fullName)
    {
        StudentID = studentID;
        ExamScores = examScores;
    }
}

class Program
{
    static void Main()
    {
        List<Student> students = new List<Student>();

        // Добавление студентов в список
        students.Add(new Student("Иванов Михаил Романович", "12345", new List<double> { 4.5, 3.8, 3.2, 3.7 }));
        students.Add(new Student("Сидоров Валерий Иванович", "54321", new List<double> { 4.2, 4.0, 4.5, 3.9 }));
        students.Add(new Student("Смирнов Александр Сергеевич", "98765", new List<double> { 3.9, 4.1, 4.3, 4.4 }));
        students.Add(new Student("Николаева Зинаида Петровна", "13579", new List<double> { 3.9, 4.1, 4.3, 4.2 }));
        // Фильтрация студентов по среднему баллу
        List<Student> filteredStudents = new List<Student>();
        foreach (Student student in students)
        {
            if (student.GetAverageScore() >= 4)
            {
                filteredStudents.Add(student);
            }
        }

        // Сортировка студентов по убыванию среднего балла
        filteredStudents.Sort((s1, s2) => s2.GetAverageScore().CompareTo(s1.GetAverageScore()));

        // Вывод результатов в виде таблицы
        Console.WriteLine("ФИО\t\t\t\tНомер студ. билета\tСредний балл");
        foreach (Student student in filteredStudents)
        {
            Console.WriteLine($"{student.FullName}\t\t{student.StudentID}\t\t\t{student.GetAverageScore()}");
        }
        Console.WriteLine();
        ISer[] serializers = new ISer[]
        {
            new MySerializeJson(),
            new MySerializeXML(),
            new MySerializeBin()
        };
        string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
        string folder = "Students";
        path = Path.Combine(path, folder);
        if (!Directory.Exists(path)) Directory.CreateDirectory(path);
        string[] files = new string[]
        {
            "students.json",
            "students.xml",
            "students.bin"
        };
        for (int i = 0; i < serializers.Length; i++)
        {
            serializers[i].Write(students, Path.Combine(path, files[i]));
        }
        for (int i = 0; i < serializers.Length; i++)
        {
            students = serializers[i].Read<List<Student>>(Path.Combine(path, files[i]));
            foreach (var student in students)
            {
                Console.WriteLine($"{student.FullName}\t\t{student.StudentID}\t\t\t{student.GetAverageScore()}");
            }
        }
        Console.ReadKey();
    }
}
