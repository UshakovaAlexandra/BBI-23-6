﻿using ProtoBuf;
using lab9_task1;

[ProtoContract]
[Serializable]
public class Participant
{
    private string lastName;
    private string society;
    private double firstAttempt;
    private double secondAttempt;
    private bool disqualified;

    [ProtoMember(1)]
    public string LastName
    {
        get { return lastName; }
        set { lastName = value; }
    }
    [ProtoMember(2)]
    public string Society
    {
        get { return society; }
        set { society = value; }
    }
    [ProtoMember(3)]
    public double FirstAttempt
    {
        get { return firstAttempt; }
        set { firstAttempt = value; }
    }
    [ProtoMember(4)]
    public double SecondAttempt
    {
        get { return secondAttempt; }
        set { secondAttempt = value; }
    }
    [ProtoMember(5)]
    public bool Disqualified
    {
        get { return disqualified; }
        set { disqualified = value; }
    }

    public double GetTotalDistance()
    {
        return FirstAttempt + SecondAttempt;
    }

    public void Disqualify()
    {
        disqualified = true;
    }

    public void PrintParticipantInfo()
    {
        Console.WriteLine($"{LastName}\t{Society}\t{GetTotalDistance()}");
    }
}

class Program
{
    static void Main()
    {
        List<Participant> participants = new List<Participant>();

        // Добавление участников в список
        participants.Add(new Participant { LastName = "Иванов", Society = "Общество 1", FirstAttempt = 7.2, SecondAttempt = 7.5 });
        participants.Add(new Participant { LastName = "Петров", Society = "Общество 2", FirstAttempt = 7.8, SecondAttempt = 8.0 });
        participants.Add(new Participant { LastName = "Сидоров", Society = "Общество 1", FirstAttempt = 6.0, SecondAttempt = 6.2 });

        // Дисквалификация участника
        DisqualifyParticipant(participants, "Сидоров");

        // Сортировка результатов по сумме двух попыток и исключение дисквалифицированных участников
        participants = participants.Where(p => !p.Disqualified).OrderByDescending(p => p.GetTotalDistance()).ToList();

        // Вывод протокола
        Console.WriteLine("Место\tФамилия\tОбщество\tРезультат");
        for (int i = 0; i < participants.Count; i++)
        {
            Participant participant = participants[i];
            participant.PrintParticipantInfo();
        }
        Console.WriteLine();
        ISer[] serializers = new ISer[]
        {
            new MySerializeJson(),
            new MySerializeXML(),
            new MySerializeBin()
        };
        string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
        string folder = "Participants";
        path = Path.Combine(path, folder);
        if (!Directory.Exists(path)) Directory.CreateDirectory(path);
        string[] files = new string[]
        {
            "participants.json",
            "participants.xml",
            "participants.bin"
        };
        for (int i = 0; i < serializers.Length; i++)
        {
            serializers[i].Write(participants, Path.Combine(path, files[i]));
        }
        for (int i = 0; i < serializers.Length; i++)
        {
            participants = serializers[i].Read<List<Participant>>(Path.Combine(path, files[i]));
            foreach (var participant in participants)
            {
                participant.PrintParticipantInfo();
            }
        }
        Console.ReadKey();
    }

    static void DisqualifyParticipant(List<Participant> participants, string lastName)
    {
        Participant participantToDisqualify = participants.Find(p => p.LastName == lastName);
        if (participantToDisqualify != null)
        {
            participantToDisqualify.Disqualify();
        }
    }
}
