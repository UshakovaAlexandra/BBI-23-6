namespace ConsoleApp2;

public interface ISerializer<T> where T : class
{
    public abstract void Write(T obj, string path);
    public abstract T Read(string path);
}