using System.Text.Json;

namespace ConsoleApp2;

public class MyJsonSerializer<T> : ISerializer<T> where T : class
{
    public void Write(T obj, string path)
    {
        using (FileStream fs = new FileStream(path, FileMode.Create))
        {
            JsonSerializer.Serialize<T>(fs, obj);
        }
    }

    public T Read(string path)
    {
        using (FileStream fs = new FileStream(path, FileMode.OpenOrCreate))
        {
            return JsonSerializer.Deserialize<T>(fs);
        }
    }
}