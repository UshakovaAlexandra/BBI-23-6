﻿using System.Text.Json.Serialization;
using System.Xml.Serialization;
using ProtoBuf;

namespace ConsoleApp2;

[Serializable]
[ProtoContract]
[JsonDerivedType(typeof(Russia), typeDiscriminator: "russia")]
[JsonDerivedType(typeof(Japan), typeDiscriminator: "japan")]
[XmlInclude(typeof(Russia))]
[XmlInclude(typeof(Japan))]
[ProtoInclude(10, typeof(Russia))]
[ProtoInclude(11, typeof(Japan))]
public abstract class Country
{
    [ProtoMember(1)] public string Name { get; set; }
    [ProtoMember(2)] public List<Answer> Answers { get; set; }

    [ProtoIgnore]
    [JsonIgnore]
    [XmlIgnore] 
    private bool IsSerialize { get; set; }
    
    [ProtoIgnore]
    [JsonIgnore]
    [XmlIgnore]
    private Dictionary<string, Dictionary<string, int>> Dictionary { get; set; } =
        new Dictionary<string, Dictionary<string, int>>();

    [ProtoIgnore]
    [JsonIgnore]
    [XmlIgnore]
    private Dictionary<string, int> Dictionary2 { get; set; } = new Dictionary<string, int>();

    protected Country()
    {
        IsSerialize = true;
    }

    [JsonConstructor]
    protected Country(string name, List<Answer> answers)
    {
        Name = name;
        Answers = answers;
        Init();
    }

    private void Init()
    {
        foreach (Answer answer in Answers)
        {
            Dictionary2[answer.Title] = answer.AnswersList.Count;
            Dictionary[answer.Title] = new Dictionary<string, int>();
            foreach (string s in answer.AnswersList)
            {
                if (Dictionary[answer.Title].ContainsKey(s))
                {
                    Dictionary[answer.Title][s]++;
                }
                else
                {
                    Dictionary[answer.Title][s] = 1;
                }
            }
        }
    }

    public override string ToString()
    {
        if (IsSerialize)
        {
            Init();
        }
        string ans = $"Ответы для {Name}\n";
        foreach (string key in Dictionary.Keys)
        {
            ans += $"Ответы на вопрос {key}:\n";
            foreach (string s in Dictionary[key].Keys)
            {
                ans += $"Ответ {s}: {(double)Dictionary[key][s] / Dictionary2[key]}%\n";
            }

            ans += "\n";
        }

        return ans;
    }
}

[Serializable]
[ProtoContract]
public class Answer
{
    [ProtoMember(3)] public string Title { get; set; }
    [ProtoMember(4)] public List<string> AnswersList { get; set; }

    public Answer()
    {
    }

    [JsonConstructor]
    public Answer(string title, List<string> answersList)
    {
        Title = title;
        AnswersList = answersList;
    }
}

[Serializable]
[ProtoContract]
public class Russia : Country
{
    public Russia()
    {
    }

    [JsonConstructor]
    public Russia(List<Answer> answers) : base("Russia", answers)
    {
    }
}

[Serializable]
[ProtoContract]
public class Japan : Country
{
    public Japan()
    {
    }

    [JsonConstructor]
    public Japan(List<Answer> answers) : base("Japan", answers)
    {
    }
}

public class Program
{
    public static void Main(string[] args)
    {
        Answer answer1 = new Answer("Животные",
            new List<string>() { "Кошка", "Собака", "Рыба", "Рыба", "Кошка", "Кролик", "Кошка" });
        Answer answer2 = new Answer("Черты характера",
            new List<string>() { "Самообладание", "Вежливость", "Трудолюбие", "Трудолюбие", "Трудолюбие" });
        Answer answer3 = new Answer("Понятия",
            new List<string>() { "Чайная церемония", "Сакура", "Сакура", "Суши", "Самурай", "Суши", "Сакура" });
        Japan japan = new Japan(new List<Answer>() { answer1, answer2, answer3 });

        Answer answer4 = new Answer("Животные",
            new List<string>() { "Кошка", "Собака", "Волк", "Медведь", "Лиса", "Медведь", "Медведь" });
        Answer answer5 = new Answer("Черты характера",
            new List<string>() { "Злой", "Грубый", "Трудолюбие", "Трудолюбие", "Грубый", "Неотёсанный" });
        Answer answer6 = new Answer("Понятия",
            new List<string>() { "Банька", "Банька", "Водочка", "Водочка", "Банька", "Банька", "Водочка" });
        Russia russia = new Russia(new List<Answer>() { answer4, answer5, answer6 });

        Country[] countries =
        {
            russia,
            japan
        };

        string[] paths =
        {
            "countries.json",
            "countries.xml",
            "countries.bin"
        };

        ISerializer<Country[]>[] serializers =
        {
            new MyJsonSerializer<Country[]>(),
            new MyXmlSerializer<Country[]>(),
            new MyBinarySerializer<Country[]>()
        };

        for (int i = 0; i < serializers.Length; i++)
        {
            serializers[i].Write(countries, paths[i]);
        }

        for (int i = 0; i < serializers.Length; i++)
        {
            Console.WriteLine(paths[i]);
            foreach (Country country in serializers[i].Read(paths[i]))
            {
                Console.WriteLine(country);
            }
        }
    }
}