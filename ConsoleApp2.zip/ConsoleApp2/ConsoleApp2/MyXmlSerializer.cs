using System.Xml.Serialization;

namespace ConsoleApp2;

public class MyXmlSerializer<T> : ISerializer<T> where T : class
{
    public T Read(string filename)
    {
        XmlSerializer xmlSerializer = new XmlSerializer(typeof(T));
        using (FileStream fs = new FileStream(filename, FileMode.OpenOrCreate))
        {
            return xmlSerializer.Deserialize(fs) as T;
        }
    }

    public void Write(T t, string filename)
    {
        XmlSerializer xmlSerializer = new XmlSerializer(typeof(T));
        using (FileStream fs = new FileStream(filename, FileMode.Create))
        {
            xmlSerializer.Serialize(fs, t);
        }
    }
}