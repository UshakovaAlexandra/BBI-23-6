using ProtoBuf;

namespace ConsoleApp2;

public class MyBinarySerializer<T> : ISerializer<T> where T : class
{
    public void Write(T obj, string path)
    {
        using (FileStream fs = new FileStream(path, FileMode.Create))
        {
            Serializer.Serialize<T>(fs, obj);
        }
    }

    public T Read(string path)
    {
        using (FileStream fs = new FileStream(path, FileMode.OpenOrCreate))
        {
            return Serializer.Deserialize<T>(fs);
        }
    }
}