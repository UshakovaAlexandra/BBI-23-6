﻿using System;
using System.Collections.Generic;
using System.Linq;
using lab9_task3;
using ProtoBuf;


[ProtoContract]
[Serializable]
[ProtoInclude(1, typeof(Russia))]
[ProtoInclude(2, typeof(Japan))]
public class Country
{
    [ProtoMember(3)]
    public string CountryName { get; set; }
    [ProtoMember(4)]
    public Dictionary<string, int> Answers { get; set; }
    public Country() { }
    public Country(string countryName, Dictionary<string, int> answers)
    {
        CountryName = countryName;
        Answers = answers;
    }

    public virtual string GetCountryName()
    {
        return "Страна";
    }
    public void PrintSurveyResults(Dictionary<string, double> topAnswers)
    {
        Console.WriteLine($"Ответы для {GetCountryName()}:");
        if (topAnswers.Count == 0)
        {
            Console.WriteLine("Нет ответов на данный вопрос.");
        }
        else
        {
            Console.WriteLine("Ответ\t\tДоля (%)");
            foreach (KeyValuePair<string, double> answer in topAnswers)
            {
                Console.WriteLine($"{answer.Key}\t\t{answer.Value:F2}");
            }
        }
        Console.WriteLine();
    }
}
[ProtoContract]
[Serializable]
public class Russia : Country
{
    [ProtoMember(5)]
    public int Svoystvo { get; set; }
    public Russia() { }
    public Russia(Dictionary<string, int> answers) : base("Россия", answers) { }

    public override string GetCountryName()
    {
        return "Россия";
    }
}
[ProtoContract]
[Serializable]
public class Japan : Country
{
    public Japan() { }
    public Japan(Dictionary<string, int> answers) : base("Япония", answers) { }

    public override string GetCountryName()
    {
        return "Япония";
    }
}
[ProtoContract]
[Serializable]
public class Survey
{
    [ProtoMember(5)]
    public Dictionary<string, List<string>> Questions { get; set; }
    public Survey() { }
    public Survey(Dictionary<string, List<string>> questions)
    {
        Questions = questions;
    }

    public Dictionary<string, double> GetTopAnswers(Dictionary<string, int> answers)
    {
        Dictionary<string, double> topAnswers = new Dictionary<string, double>();
        int totalAnswers = answers.Values.Sum();
        foreach (var answer in answers)
        {
            topAnswers[answer.Key] = (double)answer.Value / totalAnswers * 100;
        }
        return topAnswers;
    }
}

class Program
{
    static void Main()
    {
        // Получение ответов на вопросы
        var surveyQuestions = new Dictionary<string, List<string>>
        {
            { "Животные", new List<string> { "Кошка", "Собака", "Рыба", "Рыба", "Кошка", "Кролик", "Кошка" } },
            { "Черты характера", new List<string> { "Самообладание", "Вежливость", "Трудолюбие", "Трудолюбие", "Трудолюбие" } },
            { "Понятия", new List<string> { "Чайная церемония", "Сакура", "Сакура", "Суши", "Самурай", "Суши", "Сакура" } }
        };
        var survey = new Survey(surveyQuestions);

        // Создание объектов для стран
        var russiaAnswers = new Dictionary<string, int> { { "Кошка", 3 }, { "Рыба", 2 }, { "Кролик", 1 } };
        var russia = new Country("Russia", russiaAnswers);

        var japanAnswers = new Dictionary<string, int> { { "Сакура", 4 }, { "Суши", 2 }, { "Самурай", 1 } };
        var japan = new Country("Japan", japanAnswers);
        Country[] countries = { russia, japan };
        // Получение ответов для каждой страны
        var topRussiaAnswers = survey.GetTopAnswers(russia.Answers);
        var topJapanAnswers = survey.GetTopAnswers(japan.Answers);

        // Вывод результатов для каждой страны
        russia.PrintSurveyResults(topRussiaAnswers);
        japan.PrintSurveyResults(topJapanAnswers);

        // Объединенные ответы
        var combinedAnswers = new Dictionary<string, int>();
        foreach (var question in surveyQuestions)
        {
            foreach (var answer in question.Value)
            {
                if (combinedAnswers.ContainsKey(answer))
                {
                    combinedAnswers[answer]++;
                }
                else
                {
                    combinedAnswers[answer] = 1;
                }
            }
        }
        var topCombinedAnswers = survey.GetTopAnswers(combinedAnswers);

        // Вывод общих результатов
        Console.WriteLine("Общие ответы для обеих стран:");
        foreach (var answer in topCombinedAnswers)
        {
            Console.WriteLine($"{answer.Key}\t\t{answer.Value:F2}");
        }
        Console.WriteLine("\n\n");
        ISer[] serializers = new ISer[]
        {
            new MySerializeJson(),
            new MySerializeXML(),
            new MySerializeBin()
        };
        string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
        string folder = "Countries";
        path = Path.Combine(path, folder);
        if (!Directory.Exists(path)) Directory.CreateDirectory(path);
        string[] files = new string[]
        {
            "countries.json",
            "countries.xml",
            "countries.bin"
        };
        for (int i = 0; i < serializers.Length; i++)
        {
            serializers[i].Write(countries, Path.Combine(path, files[i]));
        }
        for (int i = 0; i < serializers.Length; i++)
        {
            countries = serializers[i].Read<Country[]>(Path.Combine(path, files[i]));
            foreach(var country in countries)
            {
                Console.WriteLine(country.CountryName);
            }
            
        }
        Console.ReadKey();
    }
}
